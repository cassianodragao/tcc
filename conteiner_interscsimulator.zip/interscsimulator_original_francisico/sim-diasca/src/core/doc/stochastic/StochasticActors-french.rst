.. role:: raw-html(raw)
   :format: html

.. role:: raw-latex(raw)
   :format: latex



.. _acteur probabiliste:
.. _acteurs probabilistes:

.. _acteur stochastique:
.. _acteurs stochastiques:



Mod�lisation des acteurs probabilistes (``StochasticActor``)
============================================================

.. Note:: A r�diger.
