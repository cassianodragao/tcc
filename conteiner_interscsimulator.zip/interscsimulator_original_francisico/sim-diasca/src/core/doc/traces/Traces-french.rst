.. contents::
	:depth: 2
	:local:


.. include:: TraceFormat-french.rst


:raw-latex:`\pagebreak`

.. include:: TraceEmitters-french.rst


:raw-latex:`\pagebreak`

.. include:: TraceAggregators-french.rst


:raw-latex:`\pagebreak`

.. include:: TraceSupervisors-french.rst


:raw-latex:`\pagebreak`

.. include:: TraceRecorders-french.rst


:raw-latex:`\pagebreak`

.. include:: TraceInterpreters-french.rst
