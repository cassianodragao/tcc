.. role:: raw-html(raw)
   :format: html

.. role:: raw-latex(raw)
   :format: latex




.. _approche de simulation r�partie:
.. _approche de simulation distribu�e:
.. _approche de simulation:
.. _approche:




Description de l'approche retenue dans Sim-Diasca en terme de simulation r�partie
=================================================================================

.. Note:: Cette description est obsol�te, se r�f�rer � la documentation en anglais pour disposer d'informations � jour.



Voir aussi :

 - le `gestionnaire de temps`_, qui cadence tous les acteurs, y compris le ou les gestionnaires de variables stochastiques

 - l'`acteur stochastique`_, un acteur sp�cialis� dont le mod�le fait usage de variables stochastiques et qui int�gre un m�canisme de gestion automatique de ces variables
