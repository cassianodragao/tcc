:raw-latex:`\pagebreak`

.. _LGPL:

------------------
Sim-Diasca License
------------------

Sim-Diasca is free software; it has been developed by `EDF R&D <http://innovation.edf.com>`_ and is released under the `GNU LGPL licence <http://www.gnu.org/licenses/lgpl.html>`_ (GNU LESSER GENERAL PUBLIC LICENSE, Version 3).


.. :raw-html:`<img src="xkcd-open_source.png"></img>`
.. :raw-latex:`\includegraphics[scale=0.7]{xkcd-open_source.png}`
