:raw-latex:`\pagebreak`


--------------------------
Contributing To Sim-Diasca
--------------------------

Of course contributions of all kinds (code, documentation, examples, etc.)  are welcome:

:raw-html:`<img src="xkcd-study.png"></img>`
:raw-latex:`\includegraphics[scale=0.7]{xkcd-study.png}`

We cannot guarantee that all patches will be integrated, but we surely will review them and do our best to make use of them, provided the original author accepts they end up in the public release and under the same licensing terms as the rest of Sim-Diasca.
