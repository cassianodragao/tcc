:raw-latex:`\pagebreak`

.. _credits:

------------------
Sim-Diasca Credits
------------------

Special thanks to **Randall Munroe** who is the author of all the comic strips that enliven this documentation, and who kindly allowed their use in this material.

See his `XKCD <http://xkcd.com/>`_ website for all information, including for all his delightful other strips.
