A Few Statistics About the Code Of Sim-Diasca Versions
------------------------------------------------------

They can be obtained by running ``make stats``.

2.0.10
******

In the Erlang source code found from /home/boudevil/Projects/Sim-Diasca/sources/Sim-Diasca/branches/sim-diasca-2.0, we have:

- 169 source files (*.erl), 31 header files (*.hrl)
- a grand total of 59458 lines:

 - 17681 of which (29.7%) are blank lines
 - 18967 of which (31.8%) are comments
 - 22810 of which (38.3%) are code



2.1.0
*****

In the Erlang source code found from /home/boudevil/Projects/Sim-Diasca/sources/Sim-Diasca/branches/sim-diasca-2.0, we have:

- 188 source files (*.erl), 45 header files (*.hrl)
- a grand total of 88610 lines:

 - 27767 of which (31.3%) are blank lines
 - 28612 of which (32.2%) are comments
 - 32231 of which (36.3%) are code



2.1.1
*****

In the Erlang source code found from /home/boudevil/Projects/Sim-Diasca/sources/Sim-Diasca/branches/sim-diasca-2.0, we have:

- 197 source files (*.erl), 46 header files (*.hrl)
- a grand total of 97362 lines:

 - 30575 of which (31.4%) are blank lines
 - 31116 of which (31.9%) are comments
 - 35671 of which (36.6%) are code
