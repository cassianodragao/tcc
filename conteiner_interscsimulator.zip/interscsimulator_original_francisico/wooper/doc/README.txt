All documentation for WOOPER should be read from:

 http://ceylan.sourceforge.net/main/documentation/wooper/
